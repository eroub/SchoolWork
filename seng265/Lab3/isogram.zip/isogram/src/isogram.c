#include <stdio.h>
#include <ctype.h>  //tolower
#include <string.h> //strlen
#include "isogram.h"

bool
is_isogram(const char phrase[])
{
    fprintf(stderr, "phrase='%s'\n", phrase); 
    return true;
}
